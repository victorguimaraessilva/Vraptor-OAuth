#Some setup information :).

##VRaptor basic setup

Maybe you receive a exception like **java.lang.AssertionError: Parameters aren't present for remove. You must compile your code with -parameters argument.**. In that case, in your eclipse, go to preferences -> compiler -> store information about method parameters
  	
##VRaptor mailer plugin

You need to change your **development.properties** file and put all information about your mail server.
  	

